# G4_BED_GradedProject4
An employee management system built using Spring, Thymeleaf and Hibernate
